<?php
return [
    'app_url' => 'http://localhost/projekt5',
    'app_root' => __DIR__ . '/../',
    'db_host' => 'localhost',
    'db_user' => 'root',
    'db_pass' => '',
    'db_name' => 'projekt5'
];
?>
