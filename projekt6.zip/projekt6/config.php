<?php
return [
    'app_url' => 'http://localhost/projekt5',
    'app_root' => __DIR__ . '/',
    'login_user' => 'admin',
    'login_pass' => '1234'
];
?>
