<?php
namespace app\controllers;
class MainCtrl {
    public function defaultAction(){
        include __DIR__ . '/../../views/templates/MainView.tpl.php';
    }
}
?>
