<?php
/* Smarty version 3.1.39, created on 2025-04-29 01:31:52
  from 'C:\xampp\htdocs\projekt6\views\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_68100fe809d0e4_93494926',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '27111566e491c6a1fb73b237b19c7a2b2baec57c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt6\\views\\templates\\footer.tpl',
      1 => 1745883110,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_68100fe809d0e4_93494926 (Smarty_Internal_Template $_smarty_tpl) {
?><footer>
  <div class="container">
    <p>&copy; 2025 Projekt6. Yaraslau.</p>
  </div>
</footer>
</body>
</html>
<?php }
}
