<?php
/* Smarty version 3.1.39, created on 2025-04-29 01:54:26
  from 'C:\xampp\htdocs\projekt6\views\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_681015320de104_78703257',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3128f9d9720f9cead1aaf9c2d8895d8065d843b7' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt6\\views\\templates\\header.tpl',
      1 => 1745884434,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_681015320de104_78703257 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Projekt6</title>
    <link rel="stylesheet" href="/projekt6/assets/css/custom.css">
</head>
<body>
<header>
    <div class="container">
        <h1>Projekt6</h1>
        <nav>
            <ul>
                <li><a href="index.php?action=home" class="button">Strona główna</a></li>
                <li><a href="index.php?action=calc" class="button">Kalkulator kredytowy</a></li>
                <li><a href="index.php?action=login" class="button">Logowanie</a></li>
            </ul>
        </nav>
    </div>
</header>
<?php }
}
