<?php
/* Smarty version 5.4.2, created on 2025-04-15 03:28:40
  from 'file:footer.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_67fdb64898bef2_36308120',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '07b01b9949d9e981d6f878ac601be1bbb8d63f6c' => 
    array (
      0 => 'footer.tpl',
      1 => 1744680478,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_67fdb64898bef2_36308120 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\projekt5\\views\\templates';
?><footer>
  <div class="container">
    <p>&copy;  Projekt5. Yaraslau Sakovich .</p>
  </div>
</footer>
</body>
</html>
<?php }
}
