<?php
/* Smarty version 5.4.2, created on 2025-04-15 04:06:08
  from 'file:header.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_67fdbf108980f1_60737861',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8a14002a2181b088b27c8607a757b7a309bbb84c' => 
    array (
      0 => 'header.tpl',
      1 => 1744682767,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_67fdbf108980f1_60737861 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\projekt5\\views\\templates';
?><!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <title>Projekt5</title>
  <link rel="stylesheet" href="/projekt5/assets/css/custom.css">
</head>
<body>
<header>
  <div class="container">
    <h1>Projekt5</h1>
    <nav>
      <ul>
        <li><a href="?action=default">Strona główna</a></li>
        <li><a href="?action=calc">Kalkulator kredytowy</a></li>
        <li><a href="?action=login">Logowanie</a></li>
      </ul>
    </nav>
  </div>
</header>
<?php }
}
